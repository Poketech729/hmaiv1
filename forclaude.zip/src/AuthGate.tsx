import { useState } from 'react'
import { supabase } from './lib/supabaseClient'

const BACKEND_URL = import.meta.env.VITE_BACKEND_URL || 'http://localhost:3000'

type AuthGateProps = {
  onAuthenticated: () => void
}

type FlowMode = 'choose' | 'signin' | 'signup' | 'emailOtp' | 'phoneOtp'

export default function AuthGate({ onAuthenticated }: AuthGateProps) {
  const [mode, setMode] = useState<FlowMode>('choose')
  const [step, setStep] = useState<'form' | 'sent' | 'verify'>('form')
  const [error, setError] = useState('')
  const [info, setInfo] = useState('')

  const [email, setEmail] = useState('')
  const [phone, setPhone] = useState('')
  const [password, setPassword] = useState('')
  const [firstName, setFirstName] = useState('')
  const [lastName, setLastName] = useState('')
  const [role, setRole] = useState<'patient' | 'doctor'>('patient')
  const [otpCode, setOtpCode] = useState('')

  const resetMessages = () => {
    setError('')
    setInfo('')
  }

  const handleBackendMe = async () => {
    const session = await supabase.auth.getSession()
    const token = session.data.session?.access_token
    if (!token) return

    const resp = await fetch(`${BACKEND_URL}/api/users/me`, {
      headers: { Authorization: `Bearer ${token}` },
    })

    if (!resp.ok) {
      console.warn('Backend /users/me check failed')
      return
    }

    onAuthenticated()
  }

  const handleSignInWithPassword = async () => {
    resetMessages()
    if (!email || !password) {
      setError('Email and password are required.')
      return
    }

    const { data, error } = await supabase.auth.signInWithPassword({ email, password })
    if (error || !data.session) {
      setError(error?.message || 'Failed to sign in.')
      return
    }

    await handleBackendMe()
  }

  const handleSendEmailOtp = async () => {
    resetMessages()
    if (!email) {
      setError('Email is required')
      return
    }

    const { error } = await supabase.auth.signInWithOtp({ email })
    if (error) {
      setError(error.message)
      return
    }

    setInfo('Check your email for a login link or code. If you signed up just now, complete profile in the next step.')
    setStep('sent')
  }

  const handleSendPhoneOtp = async () => {
    resetMessages()
    if (!phone) {
      setError('Phone is required in +<country><number> format')
      return
    }

    const { error } = await supabase.auth.signInWithOtp({ phone })
    if (error) {
      setError(`Phone OTP not available: ${error.message}. Try Email OTP instead.`)
      return
    }

    setInfo('Check your SMS for the OTP code. Use verify step to complete.')
    setStep('sent')
  }

  const handleVerifyPhoneOtp = async () => {
    resetMessages()
    if (!phone || !otpCode) {
      setError('Phone and OTP code are required for verification.')
      return
    }

    const { data, error } = await supabase.auth.verifyOtp({ phone, token: otpCode, type: 'sms' })
    if (error || !data.session) {
      setError(`Verification error: ${error?.message || 'OTP verification failed.'}`)
      return
    }

    await handleBackendMe()
  }

  const handleSignupEmailPassword = async () => {
    resetMessages()
    if (!email || !password || !firstName || !lastName || !phone) {
      setError('All fields are required for signup.')
      return
    }

    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: { firstName, lastName, role },
      },
    })

    if (error) {
      setError(error.message)
      return
    }

    setInfo('Signup created. Please confirm via e-mail link. Then sign in.')

    if (data.user && data.user.id) {
      const resp = await fetch(`${BACKEND_URL}/api/auth/signup/email-otp`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          firstName,
          lastName,
          email,
          phone,
          role,
          otp: otpCode || '000000',
          otpType: 'email',
        }),
      })

      if (!resp.ok) {
        const err = await resp.json().catch(() => ({}))
        setError(err.message || 'Backend profile creation failed (retry after e-mail verification).')
        return
      }

      setInfo('Profile created in backend. You may now sign in.')
    }
  }

  const handleGoogleSignIn = async () => {
    resetMessages()
    const { error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: { redirectTo: window.location.origin },
    })

    if (error) {
      setError(error.message)
      return
    }

    setInfo('Redirecting to Google login...')
  }

  return (
    <div className="auth-card" style={{ width: 'min(420px, 90vw)' }}>
        <h2>MedAssist Authentication</h2>

        <div className="auth-mode-buttons">
          <button onClick={() => { setMode('signin'); setStep('form'); resetMessages() }}>Sign In</button>
          <button onClick={() => { setMode('signup'); setStep('form'); resetMessages() }}>Sign Up</button>
          <button onClick={() => { setMode('emailOtp'); setStep('form'); resetMessages() }}>Email OTP</button>
          <button onClick={() => { setMode('phoneOtp'); setStep('form'); resetMessages() }}>Phone OTP</button>
        </div>

        {error && <p className="error">{error}</p>}
        {info && <p className="info">{info}</p>}

        {mode === 'signin' && (
          <div className="form-grid">
            <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
            <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
            <button onClick={handleSignInWithPassword}>Sign In with Email/Password</button>
            <button onClick={handleGoogleSignIn}>Sign In with Google</button>
          </div>
        )}

        {mode === 'signup' && (
          <div className="form-grid">
            <input type="text" placeholder="First Name" value={firstName} onChange={(e) => setFirstName(e.target.value)} />
            <input type="text" placeholder="Last Name" value={lastName} onChange={(e) => setLastName(e.target.value)} />
            <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
            <input type="tel" placeholder="Phone (+country)" value={phone} onChange={(e) => setPhone(e.target.value)} />
            <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
            <select value={role} onChange={(e) => setRole(e.target.value as 'patient' | 'doctor')}>
              <option value="patient">Patient</option>
              <option value="doctor">Doctor</option>
            </select>
            <button onClick={handleSignupEmailPassword}>Complete Sign Up</button>
            <p>After signup, verify email and then sign in.</p>
          </div>
        )}

        {mode === 'emailOtp' && (
          <div className="form-grid">
            <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
            <button onClick={handleSendEmailOtp}>Send sign-in OTP / magic link</button>
          </div>
        )}

        {mode === 'phoneOtp' && (
          <div className="form-grid">
            <input type="tel" placeholder="Phone (+91XXXXXXXXXX or similar)" value={phone} onChange={(e) => setPhone(e.target.value)} />
            {step === 'form' ? (
              <>
                <button onClick={handleSendPhoneOtp}>Send Phone OTP</button>
                <p style={{ fontSize: '0.85rem', color: '#666' }}>
                  ⚠️ Phone OTP may not work in all regions. If you get "provider not supported", use Email OTP or Google Sign In instead.
                </p>
              </>
            ) : (
              <>
                <input type="text" placeholder="Enter OTP" value={otpCode} onChange={(e) => setOtpCode(e.target.value)} />
                <button onClick={handleVerifyPhoneOtp}>Verify OTP</button>
              </>
            )}
          </div>
        )}

        <small>Data is stored securely in Supabase + backend DB. Token-based access prevents cross-user data leaks.</small>
      </div>
    )
}
